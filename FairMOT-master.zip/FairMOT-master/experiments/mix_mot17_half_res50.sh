cd src
python train.py mot --exp_id mix_mot17_half_res50 --arch 'resdcn_50' --data_cfg '../src/lib/cfg/data_half.json'
cd ..