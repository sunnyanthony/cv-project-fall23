from .default import _C as cfg
from .default import update_config